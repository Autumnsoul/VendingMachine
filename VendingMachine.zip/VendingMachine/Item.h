#pragma once
#include <string>
#include <iostream>
using namespace std;

//item class
//has name,price, and stock attributes
//has purchase item function(currently not in use 
class Item
{
public:
	string name;
	double price;
	int stock;
	Item(string name, double price, int stock){
		this->name=name;
		this->price=price;
		this->stock = stock;

}
		void purchaseItem() {
			if (this->stock == 0) {
				cout << "This item is out of stock";
				return;
			}
		this->stock = this->stock - 1;
		return;
	}

};


